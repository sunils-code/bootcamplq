import pandas as pd
import matplotlib.pyplot as plt

orders = pd.read_csv ( "../2020-Sales-Clean.csv" )
sumorders = orders.groupby(["Order Month"]).sum()

xcoords = orders["Order Month"].unique()
ycoords = sumorders["Sales"]

fig = plt.figure()
ax = fig.add_subplot(1,1,1)
ax.bar(xcoords,ycoords)
plt.show()

