import requests
import json

class GetWDCData():

    @classmethod
    def get_products(self):
        products = list()

        getprod = requests.get("http://127.0.0.1:5000/products",auth=('client', 'P@ssw0rd12!'))

        if getprod.status_code == 401:
            print(str(getprod.status_code)+" "+ getprod.text)
            exit()

        tmpproducts = json.loads(getprod.text)
        products = tmpproducts["products"]
        return products

    @classmethod
    def get_prices(self):
        prices = list()

        getprice = requests.get("http://127.0.0.1:5000/prices")
        tmpprices = json.loads(getprice.text)
        prices = tmpprices["prices"]
        return prices