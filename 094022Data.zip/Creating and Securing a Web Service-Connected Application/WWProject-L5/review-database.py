import mysql.connector

#Connect to wwinvetory database using MySQL connector.
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="P@ssw0rd12!",
    database="wwinventory")

mycursor = mydb.cursor()

#Print the inventory table fields.
query = "SELECT * FROM inventory"
mycursor.execute(query)

records = mycursor.fetchall()

for record in records:
    print(record)

mydb.close()

